package lab6.var1;

public class Main {
    public static void main(String[] args) {
        MainPanel panel = new MainPanel();
    }
}
