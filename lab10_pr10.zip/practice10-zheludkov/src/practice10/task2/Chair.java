package practice10.task2;

public interface Chair {
}
