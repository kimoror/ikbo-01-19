package practice10.task2;

public class MagicChair implements Chair {
    public void doMagic(){
        System.out.println("Chair do magic");
    }
}
