package ru.mirea.lab;

public class Dog {
    private String Name = "Bob";
    public String  getName(){
        return Name;
    }

}
