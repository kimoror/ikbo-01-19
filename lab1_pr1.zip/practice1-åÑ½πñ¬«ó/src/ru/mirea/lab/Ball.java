package ru.mirea.lab;

public class Ball {
    private float radius = 5.6f;
    public float getRadius(){
        return radius;
    }

}
