package ru.mirea.lab;

public class Book {
    private int pagesSize = 406;
    public int getSize() {
    return pagesSize;
    }
}
