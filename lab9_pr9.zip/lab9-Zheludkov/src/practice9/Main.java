package practice9;

public class Main {
    public static void main(String[] args) throws Exception {
        //Exception1.exeptionDemo();
        //Exception2.exceptionDemo();
        //Task3.exceptionDemo();
        //Task4.exceptionDemo();
        //Task5.printMessage(null);
        //Task6.getKey();
        //Task7.getKey();
        Task8.getKey();
    }
}
