package practice10.task1;

public interface ComplexAbstractFactory {
    public Complex createComplex();
    public Complex createComplex(int real, int image);
}
