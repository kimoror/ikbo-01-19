package practice9.FirstTask;

public class ExceptionInn extends RuntimeException {
    public ExceptionInn(String message){
        super(message);
    }
}
