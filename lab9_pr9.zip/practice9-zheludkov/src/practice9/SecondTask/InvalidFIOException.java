package practice9.SecondTask;

public class InvalidFIOException extends RuntimeException {
    public InvalidFIOException(String erorrMessage){
        super(erorrMessage);
    }
}
