package lab4.var1;

public interface Nameable {
    String getName();
}
